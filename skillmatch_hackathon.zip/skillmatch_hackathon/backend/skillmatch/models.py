from sqlalchemy import Column, Integer, String, Float, ForeignKey
from sqlalchemy.orm import relationship
from skillmatch.database import Base


# ----------------------------
# Candidate Table
# ----------------------------

class Candidate(Base):
    __tablename__ = "candidates"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    gpa = Column(Float, nullable=False)
    experience = Column(Float, nullable=False)

    skills = relationship("CandidateSkill", back_populates="candidate", cascade="all, delete")


# ----------------------------
# Skill Master Table
# ----------------------------

class Skill(Base):
    __tablename__ = "skills"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, unique=True, nullable=False)

    candidates = relationship("CandidateSkill", back_populates="skill", cascade="all, delete")
    projects = relationship("ProjectSkill", back_populates="skill", cascade="all, delete")


# ----------------------------
# Candidate Skills (Many-to-Many)
# ----------------------------

class CandidateSkill(Base):
    __tablename__ = "candidate_skills"

    candidate_id = Column(Integer, ForeignKey("candidates.id"), primary_key=True)
    skill_id = Column(Integer, ForeignKey("skills.id"), primary_key=True)
    level = Column(Integer, nullable=False)  # 1–10 scale

    candidate = relationship("Candidate", back_populates="skills")
    skill = relationship("Skill", back_populates="candidates")


# ----------------------------
# Project Table
# ----------------------------

class Project(Base):
    __tablename__ = "projects"

    id = Column(Integer, primary_key=True, index=True)
    title = Column(String, nullable=False)

    skills = relationship("ProjectSkill", back_populates="project", cascade="all, delete")


# ----------------------------
# Project Skills (Many-to-Many with Weight)
# ----------------------------

class ProjectSkill(Base):
    __tablename__ = "project_skills"

    project_id = Column(Integer, ForeignKey("projects.id"), primary_key=True)
    skill_id = Column(Integer, ForeignKey("skills.id"), primary_key=True)
    weight = Column(Float, nullable=False)  # 0.0 – 1.0

    project = relationship("Project", back_populates="skills")
    skill = relationship("Skill", back_populates="projects")