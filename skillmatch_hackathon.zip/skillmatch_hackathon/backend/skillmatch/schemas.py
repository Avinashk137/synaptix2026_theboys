from pydantic import BaseModel
from typing import List


class BreakdownItem(BaseModel):
    skill_id: int
    level: int
    weight: float
    contribution: float


class MatchResponse(BaseModel):
    final_score: float
    skill_score: float
    experience_score: float
    gpa_score: float
    breakdown: List[BreakdownItem]