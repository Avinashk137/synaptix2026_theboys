from fastapi import FastAPI, Depends
from sqlalchemy.orm import Session

from skillmatch.database import engine, Base, SessionLocal
from skillmatch import models
from skillmatch.matching import calculate_match

# Create app FIRST
app = FastAPI()

# Create tables
Base.metadata.create_all(bind=engine)


# Database dependency
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# Home route
@app.get("/")
def home():
    return {"message": "SkillMatch Backend Running"}


# Seed route
@app.get("/seed")
def seed_data(db: Session = Depends(get_db)):

    from skillmatch.models import Candidate, Skill, CandidateSkill, Project, ProjectSkill

    python = Skill(name="Python")
    react = Skill(name="React")
    ml = Skill(name="ML")

    db.add_all([python, react, ml])
    db.commit()

    db.refresh(python)
    db.refresh(react)
    db.refresh(ml)

    c1 = Candidate(name="Rahul", gpa=8.5, experience=2)
    c2 = Candidate(name="Anita", gpa=9.0, experience=1)

    db.add_all([c1, c2])
    db.commit()

    db.refresh(c1)
    db.refresh(c2)

    db.add_all([
        CandidateSkill(candidate_id=c1.id, skill_id=python.id, level=8),
        CandidateSkill(candidate_id=c1.id, skill_id=react.id, level=6),
        CandidateSkill(candidate_id=c1.id, skill_id=ml.id, level=7),

        CandidateSkill(candidate_id=c2.id, skill_id=python.id, level=9),
        CandidateSkill(candidate_id=c2.id, skill_id=ml.id, level=8)
    ])

    project = Project(title="AI Internship")
    db.add(project)
    db.commit()
    db.refresh(project)

    db.add_all([
        ProjectSkill(project_id=project.id, skill_id=python.id, weight=0.4),
        ProjectSkill(project_id=project.id, skill_id=ml.id, weight=0.4),
        ProjectSkill(project_id=project.id, skill_id=react.id, weight=0.2)
    ])

    db.commit()

    return {"message": "Demo data inserted successfully"}


# Match route
@app.get("/match/{candidate_id}/{project_id}")
def match(candidate_id: int, project_id: int, db: Session = Depends(get_db)):
    return calculate_match(db, candidate_id, project_id)

@app.get("/tables")
def check_tables(db: Session = Depends(get_db)):
    from sqlalchemy import text
    result = db.execute(
        text("SELECT name FROM sqlite_master WHERE type='table';")
    ).fetchall()

    # Convert row objects into plain strings
    table_names = [row[0] for row in result]

    return {"tables": table_names}