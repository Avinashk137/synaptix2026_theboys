from sqlalchemy.orm import Session
from sqlalchemy import text


def calculate_match(db: Session, candidate_id: int, project_id: int):

    project_skills = db.execute(
        text("SELECT skill_id, weight FROM project_skills WHERE project_id = :pid"),
        {"pid": project_id}
    ).fetchall()

    total_score = 0
    max_score = 0
    breakdown = []

    for skill_id, weight in project_skills:

        candidate_skill = db.execute(
            text("""
                SELECT level FROM candidate_skills
                WHERE candidate_id = :cid AND skill_id = :sid
            """),
            {"cid": candidate_id, "sid": skill_id}
        ).fetchone()

        max_score += 10 * weight

        if candidate_skill:
            level = candidate_skill[0]
            contribution = level * weight
            total_score += contribution
        else:
            level = 0
            contribution = 0

        breakdown.append({
            "skill_id": skill_id,
            "level": level,
            "weight": weight,
            "contribution": contribution
        })

    final_score = round((total_score / max_score) * 100, 2) if max_score else 0

    return {
        "final_score": final_score,
        "breakdown": breakdown
    }